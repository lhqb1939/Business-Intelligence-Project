Place warehouse_sales_lines_fixed.csv and promotion_eligibility_dw.csv here before running. The input CSVs are omitted from the code-only ZIP.
